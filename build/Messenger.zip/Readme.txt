Killing the Messenger
By Eike Decker
For te Global Game Jam 2018

You are a messenger to bring the Emperor the news that an enemy is invading the empire. 
Your journey will be difficult...

The game is developed for the Tiny Arcade by Tiny Circuits, an arduino compatible tiny gaming console. 
Tiny Arcade specifications: 
- 48mHz 32-bit ARM processor
- 256kb flash memory
- 32kb RAM
- 96x64 pixel OLED screen (16bit color depth)
- SD card slot


Windows:
The game can be played on windows by starting the messenger.exe file.

Tiny Arcade:
Copy the "Messenger" folder onto your SD card and select the game to start it.